package cs480.bolide.chess;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;

public class LocalChessBoard extends AppCompatActivity {


    public void init(){
        //each square in the chessboard is an ImageButton
        final ImageButton bloc1 = (ImageButton)findViewById(R.id.block1);
        final ImageButton bloc2 = (ImageButton)findViewById(R.id.block2);
        final ImageButton bloc3 = (ImageButton)findViewById(R.id.block3);
        final ImageButton bloc4 = (ImageButton)findViewById(R.id.block4);
        final ImageButton bloc5 = (ImageButton)findViewById(R.id.block5);
        final ImageButton bloc6 = (ImageButton)findViewById(R.id.block6);
        final ImageButton bloc7 = (ImageButton)findViewById(R.id.block7);
        final ImageButton bloc8 = (ImageButton)findViewById(R.id.block8);
        final ImageButton bloc9 = (ImageButton)findViewById(R.id.block9);
        final ImageButton bloc10 = (ImageButton)findViewById(R.id.block10);
        final ImageButton bloc11 = (ImageButton)findViewById(R.id.block11);
        final ImageButton bloc12 = (ImageButton)findViewById(R.id.block12);
        final ImageButton bloc13 = (ImageButton)findViewById(R.id.block13);
        final ImageButton bloc14 = (ImageButton)findViewById(R.id.block14);
        final ImageButton bloc15 = (ImageButton)findViewById(R.id.block15);
        final ImageButton bloc16 = (ImageButton)findViewById(R.id.block16);
        final ImageButton bloc17 = (ImageButton)findViewById(R.id.block17);
        final ImageButton bloc18 = (ImageButton)findViewById(R.id.block18);
        final ImageButton bloc19 = (ImageButton)findViewById(R.id.block19);
        final ImageButton bloc20 = (ImageButton)findViewById(R.id.block20);
        final ImageButton bloc21 = (ImageButton)findViewById(R.id.block21);
        final ImageButton bloc22 = (ImageButton)findViewById(R.id.block22);
        final ImageButton bloc23 = (ImageButton)findViewById(R.id.block23);
        final ImageButton bloc24 = (ImageButton)findViewById(R.id.block24);
        final ImageButton bloc25 = (ImageButton)findViewById(R.id.block25);
        final ImageButton bloc26 = (ImageButton)findViewById(R.id.block26);
        final ImageButton bloc27 = (ImageButton)findViewById(R.id.block27);
        final ImageButton bloc28 = (ImageButton)findViewById(R.id.block28);
        final ImageButton bloc29 = (ImageButton)findViewById(R.id.block29);
        final ImageButton bloc30 = (ImageButton)findViewById(R.id.block30);
        final ImageButton bloc31 = (ImageButton)findViewById(R.id.block31);
        final ImageButton bloc32 = (ImageButton)findViewById(R.id.block32);
        final ImageButton bloc33 = (ImageButton)findViewById(R.id.block33);
        final ImageButton bloc34 = (ImageButton)findViewById(R.id.block34);
        final ImageButton bloc35 = (ImageButton)findViewById(R.id.block35);
        final ImageButton bloc36 = (ImageButton)findViewById(R.id.block36);
        final ImageButton bloc37 = (ImageButton)findViewById(R.id.block37);
        final ImageButton bloc38 = (ImageButton)findViewById(R.id.block38);
        final ImageButton bloc39 = (ImageButton)findViewById(R.id.block39);
        final ImageButton bloc40 = (ImageButton)findViewById(R.id.block40);
        final ImageButton bloc41 = (ImageButton)findViewById(R.id.block41);
        final ImageButton bloc42 = (ImageButton)findViewById(R.id.block42);
        final ImageButton bloc43 = (ImageButton)findViewById(R.id.block43);
        final ImageButton bloc44 = (ImageButton)findViewById(R.id.block44);
        final ImageButton bloc45 = (ImageButton)findViewById(R.id.block45);
        final ImageButton bloc46 = (ImageButton)findViewById(R.id.block46);
        final ImageButton bloc47 = (ImageButton)findViewById(R.id.block47);
        final ImageButton bloc48 = (ImageButton)findViewById(R.id.block48);
        final ImageButton bloc49 = (ImageButton)findViewById(R.id.block49);
        final ImageButton bloc50 = (ImageButton)findViewById(R.id.block50);
        final ImageButton bloc51 = (ImageButton)findViewById(R.id.block51);
        final ImageButton bloc52 = (ImageButton)findViewById(R.id.block53);
        final ImageButton bloc53 = (ImageButton)findViewById(R.id.block53);
        final ImageButton bloc54 = (ImageButton)findViewById(R.id.block54);
        final ImageButton bloc55 = (ImageButton)findViewById(R.id.block55);
        final ImageButton bloc56 = (ImageButton)findViewById(R.id.block56);
        final ImageButton bloc57 = (ImageButton)findViewById(R.id.block57);
        final ImageButton bloc58 = (ImageButton)findViewById(R.id.block58);
        final ImageButton bloc59 = (ImageButton)findViewById(R.id.block59);
        final ImageButton bloc60 = (ImageButton)findViewById(R.id.block60);
        final ImageButton bloc61 = (ImageButton)findViewById(R.id.block61);
        final ImageButton bloc62 = (ImageButton)findViewById(R.id.block62);
        final ImageButton bloc63 = (ImageButton)findViewById(R.id.block63);
        final ImageButton bloc64 = (ImageButton)findViewById(R.id.block64);
        Bitmap kblk = BitmapFactory.decodeResource(getResources(),R.drawable.black_king);
        Bitmap qblk = BitmapFactory.decodeResource(getResources(),R.drawable.black_queen);
        Bitmap knblk = BitmapFactory.decodeResource(getResources(),R.drawable.black_knight);
        Bitmap bblk = BitmapFactory.decodeResource(getResources(),R.drawable.black_bishop);
        Bitmap rblk = BitmapFactory.decodeResource(getResources(),R.drawable.black_rook);
        Bitmap pblk = BitmapFactory.decodeResource(getResources(),R.drawable.black_pawn);

    }

    //Createa the layout
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_chess_board);
        init();
    }
}