package cs480.bolide.chess;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainMenu extends AppCompatActivity {

    public Button buttonLocal;

    //Creates an activity called LocalChessBoard when a button is called
    public void init(){
        buttonLocal = (Button)findViewById(R.id.LocalGame);
        buttonLocal.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent createGame = new Intent(MainMenu.this,LocalChessBoard.class);
                startActivity(createGame);
            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        init();
    }

}
